﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using files.Data;
using files.Models;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;

namespace files.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ColaUsuariosController : ControllerBase
    {
        private readonly CedulasContext _context;

        public ColaUsuariosController(CedulasContext context)
        {
            _context = context;
        }

        // GET: api/ColaUsuarios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ColaUsuario>>> GetColaUsuarios()
        {
            return await _context.ColaUsuarios.ToListAsync();
        }

        [HttpGet("attendant/{id}")]      //ATENDIDOS
        public async Task<ActionResult<IEnumerable<ColaUsuario>>> GetAtendidos(int id)
        {
            return await _context.ColaUsuarios.Where(x => x.Id == id && x.Status == true).OrderBy(x => x.Orden).ToListAsync();
        }
        // GET: api/ColaUsuarios/5
        [HttpGet("{id}")]            //tener colausuario registro
        public async Task<ActionResult<ColaUsuario>> GetColaUsuario(int id)
        {
            var colaUsuario = await _context.ColaUsuarios.FindAsync(id);

            if (colaUsuario == null)
            {
                return NotFound();
            }

            return colaUsuario;
        }

        // GET: api/ColaUsuarios/5
        [HttpGet("next/{id}")]        //para anunciar el siguiente
        public async Task<ActionResult<ColaUsuario>> GetNextColaUsuario(int id)
        {
            //validar si en la fila hay alguien con condicion
            var colaUsuario = await getNext(id);


            if (colaUsuario == null)
            {
                return NotFound();
            }

            return colaUsuario;
        }

        [HttpPost("nextUser/{id}")]    // Marca el que esta atendido y te trae el que sigue
        public async Task<ActionResult<ColaUsuario>> NextColaUsuario(int id)
        {
            var colaUsuario = await getNext(id);


            if (colaUsuario == null)
            {
                return NotFound();
            }

            colaUsuario.Status = true;
            _context.Entry(colaUsuario).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            return await getNext(id);
        }

        async Task<ColaUsuario> getNext(int id)
        {
            var withCondition = _context.ColaUsuarios
                .Include(x => x.User)
                .Include(x => x.Cola)
                .OrderBy(x => x.Orden)
                .Where(x => x.Colaid == id && x.Status == false && x.User.Condition != (int)Condiciones.sinCondicion);

            var colaUsuario = new ColaUsuario();
            if (withCondition.Count() == 0)
            {
                colaUsuario = await _context.ColaUsuarios.Where(x => x.Colaid == id && x.Status == false)
                       .OrderBy(x => x.Orden)
                       .Include(x => x.User).Include(x => x.Cola)
                       .FirstOrDefaultAsync();
            }
            else
            {
                colaUsuario = withCondition.FirstOrDefault(x => x.User.Condition == (int)Condiciones.embarazada);
                if (colaUsuario == null)
                {
                    colaUsuario = withCondition.FirstOrDefault();
                }
            }

            return colaUsuario;
        }

        // PUT: api/ColaUsuarios/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]                   //PA EDITA
        public async Task<IActionResult> PutColaUsuario(int id, ColaUsuario colaUsuario)
        {
            if (id != colaUsuario.Id)
            {
                return BadRequest();
            }

            _context.Entry(colaUsuario).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ColaUsuarioExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ColaUsuarios
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]                         //pa crea el registro de usuario cola
        public async Task<ActionResult<ColaUsuario>> PostColaUsuario(ColaUsuario colaUsuario)
        {
            var state = _context.ColaUsuarios.Any(x => x.Userid == colaUsuario.Userid && x.Status == false);
            if (state)
                return BadRequest("lider ta en la otra cola");
            colaUsuario.Status = false;
            var orden = _context.ColaUsuarios.OrderByDescending(x => x.Orden).FirstOrDefault()?.Orden ?? 0;
            colaUsuario.Orden = orden + 1;
            _context.ColaUsuarios.Add(colaUsuario);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetColaUsuario", new { id = colaUsuario.Id }, colaUsuario);
        }

        // DELETE: api/ColaUsuarios/5
        [HttpDelete("{id}")]             // pa elimina 
        public async Task<IActionResult> DeleteColaUsuario(int id)
        {
            var colaUsuario = await _context.ColaUsuarios.FindAsync(id);
            if (colaUsuario == null)
            {
                return NotFound();
            }

            _context.ColaUsuarios.Remove(colaUsuario);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ColaUsuarioExists(int id)
        {
            return _context.ColaUsuarios.Any(e => e.Id == id);
        }
    }
}