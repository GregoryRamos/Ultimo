﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using files.Data;
using files.Models;
using Microsoft.IdentityModel.Tokens;
using Azure.AI.FormRecognizer.DocumentAnalysis;
using Azure;

namespace files.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly CedulasContext _context;

        public UsuariosController(CedulasContext context)
        {
            _context = context;
        }

        [HttpPost("foto")]
        [Produces("application/json")]

        public async Task<Usuario> Reconocimiento([FromBody] UserRequest request) 
        {

            string endpoint = "https://proyectocedula.cognitiveservices.azure.com/";
            string apiKey = "8a9d5f027c294cd594384f9ed9d4bf8d";
            AzureKeyCredential credential = new AzureKeyCredential(apiKey);
            DocumentAnalysisClient client = new DocumentAnalysisClient(new Uri(endpoint), credential);

            string modelId = "Cedulas";
            Uri fileUri = new Uri(request.url);

            AnalyzeDocumentOperation operation = await client.AnalyzeDocumentFromUriAsync(WaitUntil.Completed, modelId, fileUri);
            AnalyzeResult result = operation.Value;

            Console.WriteLine($"Document was analyzed with model with ID: {result.ModelId}");

            var Persona = new Usuario();
            Persona.peso = request.peso;
            Persona.estatura = request.estatura;
            Persona.Condition = request.Condicion;
            Persona.Condition = getCondicion(Persona);

            foreach (AnalyzedDocument document in result.Documents)
            {
                Console.WriteLine($"Document of type: {document.DocumentType}");

                foreach (KeyValuePair<string, DocumentField> fieldKvp in document.Fields)
                {
                    string fieldName = fieldKvp.Key;
                    DocumentField field = fieldKvp.Value;

                    Console.WriteLine($"Field '{fieldName}': ");

                    Console.WriteLine($"  Content: '{field.Content}'");

                    switch (fieldName.ToString().ToLower())
                    {
                        case "nombre":
                            Persona.Name = field.Content;
                            break;

                        case "fechadenacimiento":
                            Persona.Fecha = DateTime.Parse(field.Content);
                            break;

                        case "idcedula":
                            Persona.idNumber = field.Content;
                            break;
                    }
                }
            }

            
            await _context.AddAsync(Persona);
            await _context.SaveChangesAsync();

            return Persona;
        }

        // GET: api/Usuarios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Usuario>>> GetUsuarios()
        {
            return await _context.Usuarios.ToListAsync();
        }

        // GET: api/Usuarios/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Usuario>> GetUsuario(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);

            if (usuario == null)
            {
                return NotFound();
            }

            return usuario;
        }


        // POST: api/Usuarios
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPost]
        //public async Task<ActionResult<Usuario>> PostUsuario(Usuario usuario)
        //{
        //    _context.Usuarios.Add(usuario);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction("GetUsuario", new { id = usuario.Id }, usuario);
        //}

        private int getCondicion(Usuario usuario)
        {
            if (usuario.Condition == (int)Condiciones.embarazada || usuario.Condition == (int)Condiciones.otras)
                return usuario.Condition;

            if (usuario.peso/ (usuario.estatura*usuario.estatura)> 30)
                return (int) Condiciones.sobrepeso;

            if (usuario.Fecha > DateTime.Now)
                return (int)Condiciones.edad;

            return (int) Condiciones.sinCondicion;
        }
        private bool UsuarioExists(int id)
        {
            return _context.Usuarios.Any(e => e.Id == id);
        }
    }
}

public class UserRequest
{
    public string url { get; set; }
    public float peso { get; set; }
    public float estatura { get; set; }
    public int Condicion { get; set; }
}