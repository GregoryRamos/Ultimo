﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using files.Data;
using files.Models;

namespace files.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ColasController : ControllerBase
    {
        private readonly CedulasContext _context;

        public ColasController(CedulasContext context)
        {
            _context = context;
        }

        // GET: api/Colas
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cola>>> GetColas()
        {
            return await _context.Colas.ToListAsync();
        }

        // GET: api/Colas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Cola>> GetCola(int id)
        {
            var cola = await _context.Colas.FindAsync(id);

            if (cola == null)
            {
                return NotFound();
            }

            return cola;
        }

        // PUT: api/Colas/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCola(int id, Cola cola)
        {
            if (id != cola.Id)
            {
                return BadRequest();
            }

            _context.Entry(cola).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ColaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Colas
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Cola>> PostCola(Cola cola)
        {
            _context.Colas.Add(cola);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCola", new { id = cola.Id }, cola);
        }

        // DELETE: api/Colas/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCola(int id)
        {
            var cola = await _context.Colas.FindAsync(id);
            if (cola == null)
            {
                return NotFound();
            }

            _context.Colas.Remove(cola);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ColaExists(int id)
        {
            return _context.Colas.Any(e => e.Id == id);
        }
    }
}
