﻿using NuGet.Versioning;
using System;
using System.Collections.Generic;

namespace files.Models
{
    public partial class Usuario
    {
        public Usuario()
        {
            //ColaUsuarios = new HashSet<ColaUsuario>();
        }

        public int Id { get; set; }
        public string? Name { get; set; }
        public string idNumber { get; set; }
        public DateTime? Fecha { get; set; }
        public int Condition { get; set; }

        public float? estatura { get; set; }

        public float? peso { get; set; }

        //public virtual ICollection<ColaUsuario> ColaUsuarios { get; set; }
    }

    public enum Condiciones
    {
        embarazada = 1,
        sobrepeso,
        otras,
        edad,
        sinCondicion
    }
}
