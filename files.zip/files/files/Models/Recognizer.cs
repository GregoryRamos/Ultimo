﻿namespace files.Models
{
    public class Recognizer
    {
        public string idCedula { get; set; }
        public string nombre { get; set; }
        public string fecha { get; set; }
    }
}
