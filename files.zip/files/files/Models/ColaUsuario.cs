﻿using System;
using System.Collections.Generic;

namespace files.Models
{
    public partial class ColaUsuario
    {
        public int Id { get; set; }
        public int? Userid { get; set; }
        public int? Colaid { get; set; }
        public int? Orden { get; set; }
        public bool? Status { get; set; }

        public virtual Cola? Cola { get; set; }
        public virtual Usuario? User { get; set; }
    }
}
